import 'bootstrap/dist/css/bootstrap.min.css';
import './Form.css';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

function Form() {

    return (
        <div className="container mt-4">
            <h1>DIGI-VIGI</h1>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="diaryNo" className="form-label">Diary No.</label>
                    <input type="text" id="diaryNo" className="form-control" placeholder="Enter Diary No." />
                </div>
                <div className="col-md-6">
                    <label htmlFor="receivedDate" className="form-label">Received Date </label><br/>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <DatePicker/>
                    </LocalizationProvider>
                </div>
            </div>

            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="category" className="form-label">Category</label>
                    <select id="category" className="form-control">
                        <option value="">-Select-</option>
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                        <option value="option3">Option 3</option>
                        <option value="option4">Option 4</option>
                        <option value="option5">Option 5</option>
                    </select>
                </div>
            </div>

            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="medium" className="form-label">Medium</label>
                    <input type="text" id="medium" className="form-control" placeholder="Enter Medium" />
                </div>
                <div className="col-md-6">
                    <label htmlFor="route" className="form-label">Route</label>
                    <select id="route" className="form-control">
                        <option value="">-Select-</option>
                        <option value="route1">Option 1</option>
                        <option value="route2">Option 2</option>
                        <option value="route3">Option 3</option>
                        <option value="route4">Option 4</option>
                    </select>
                </div>
            </div>

            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="complainantName" className="form-label">Complainant Name</label>
                    <input type="text" id="complainantName" className="form-control" placeholder="Enter Complainant Name" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="complain" className="form-label">Complain</label>
                    <input type="text" id="complain" className="form-control" placeholder="Enter Complain" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="phone" className="form-label">Phone</label>
                    <input type="text" id="phone" className="form-control" placeholder="Enter Phone Number" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="description" className="form-label">Other Description</label>
                    <input type="text" id="description" className="form-control" placeholder="Enter Description" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="gst" className="form-label">GST</label>
                    <input type="text" id="gst" className="form-control" placeholder="Enter GST Number" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="attachment" className="form-label">Attachment</label>
                    <input type="file" id="attachment" className="form-control" />
                </div>
            </div>
            <div className="row mb-3">
                <div className="col-md-6">
                    <label htmlFor="complaintDivision" className="form-label">Complaint Division</label>
                    <select id="complaintDivision" className="form-control">
                        <option value="">-Select-</option>
                        <option value="division1">Option 1</option>
                        <option value="division2">Option 2</option>
                        <option value="division3">Option 3</option>
                        <option value="division4">Option 4</option>
                        <option value="division5">Option 5</option>
                    </select>
                </div>
            </div>

            <div className="mb-3">
                <button type="button" className="btn btn-primary">Save</button>
                <button type="button" className="btn btn-success ms-2">Submit</button>
            </div>
        </div>
    );
}

export default Form;
